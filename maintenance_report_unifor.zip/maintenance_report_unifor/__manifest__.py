{
    'name': 'Maintenance Report Unifor',
    'version': '18.0.1.0.0',
    'category': 'Maintenance',
    'summary': 'Reporte PDF para Acta de Entrega de Uniforme',
    'website': 'https://callphoneecuador.com',
    'license': 'LGPL-3',
    'description': """
        Este módulo permite generar Acta de entrega de uniforme.
    """,
    'author': 'Ing. Bolivar Rodriguez',
    'depends': ['maintenance_report'],
    'data': [
        'security/ir.model.access.csv',
        'report/maintenance_report_views.xml',
        'report/maintenance_report_templates.xml',
        'views/hr_equipment_view_form.xml',
        'views/maintenance_product_category_view.xml',
        'data/ir_sequence.xml',
    ],
    'assets': {
        'web.assets_frontend': [

        ],
    },

    'installable': True,
    'application': False,
    'auto_install': False,

 }