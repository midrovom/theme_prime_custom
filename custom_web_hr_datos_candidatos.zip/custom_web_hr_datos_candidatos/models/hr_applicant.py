from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

DOCUMENT_TYPES = [
    ('cedula', 'Cédula'),
    ('id_extrj', 'Cédula extranjera'),
    ('pasaporte', 'Pasaporte'),
]


class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    # Relaciones existentes
    education_ids = fields.One2many('applicant.education', 'applicant_id', string='Formación Académica')
    experience_job_ids = fields.One2many('applicant.experience.job', 'applicant_id', string='Experiencia Laboral')
    family_ids = fields.One2many('applicant.family', 'applicant_id', string='Familiares')
    known_ids = fields.One2many('applicant.known', 'applicant_id', string='Familiares o Conocidos del Grupo Empresarial')
    reference_ids = fields.One2many('applicant.reference', 'applicant_id', string='Referencias Personales')
    provincia_id = fields.Many2one('res.country.state', string='Provincia')
    medical_ids = fields.One2many('applicant.medical', 'applicant_id', string="Información Médica")
    candidate_id = fields.Many2one('hr.candidate', string="Candidato", ondelete='cascade')
    document_ids  = fields.One2many('applicant.document', 'applicant_id', string="Documentos adjuntos")

    image_1920 = fields.Binary("Foto de perfil") 
    disability = fields.Boolean('Discapacidad', default=False)
    family_disability = fields.Boolean('Familiar con Discapacidad', default=False)
    secondary_studies = fields.Boolean('Estudios Secundarios', default=False)
    terms_conditions = fields.Boolean('Términos y condiciones')
    birthdate = fields.Date(string="Fecha de Nacimiento")
    age = fields.Integer(string="Edad")
    address = fields.Char(string="Dirección de domicilio")
    parish = fields.Char(string="Parroquia")
    birth_country_id = fields.Many2one('res.country', string="Lugar de nacimiento (país)")
    partner_mobile = fields.Char(string="Celular")
    code_cellphone = fields.Char(string="Código de celular")
    document_type = fields.Selection(DOCUMENT_TYPES, string='Tipo de documento')
    cedula = fields.Char(string='Número de documento')
    nacionality = fields.Char(string='Nacionalidad')
    experiencia = fields.Char(string="Cantidad de experiencia")

    portal_user_id = fields.Many2one('res.users', string="Usuario del portal", ondelete="set null")

    estado_civil = fields.Selection([
        ('soltero', 'Soltero'),
        ('casado', 'Casado'),
        ('divorciado', 'Divorciado'),
        ('union_libre', 'Unión libre'),
        ('otro', 'Otro'),
    ], string="Estado civil")

    vive_con = fields.Selection([
        ('padres', 'Padres'),
        ('familia', 'Familia'),
        ('parientes', 'Parientes'),
        ('conyuge', 'Cónyuge'),
        ('solo', 'Solo'),
        ('otro', 'Otro'),
    ], string="Vive con")

    tipo_vivienda = fields.Selection([
        ('propia', 'Propia'),
        ('arrendada', 'Arrendada'),
    ], string="Tipo de vivienda")

    num_hijos = fields.Integer(string="Número de hijos")
    dependientes = fields.Char(string="Personas que dependen de usted")

    # Validar documentos (Cedula, Pasaporte, Cedula Extranjera)
    @api.model
    def is_valid_ecuadorian_id(self, value):
        cedula = "".join(filter(str.isdigit, value or ""))
        if len(cedula) != 10:
            return False
        province = int(cedula[:2])
        if province < 1 or province > 24 or int(cedula[2]) > 5:
            return False
        coefficients = [2, 1, 2, 1, 2, 1, 2, 1, 2]
        total = 0
        for index, coefficient in enumerate(coefficients):
            product = int(cedula[index]) * coefficient
            total += product - 9 if product >= 10 else product
        verifier = (10 - total % 10) % 10
        return verifier == int(cedula[9])

    @api.model
    def is_valid_foreign_id(self, id_number):
        """Validación para documentos extranjeros: solo números y 10 dígitos"""
        if not id_number:
            return False
        return id_number.isdigit() and len(id_number) == 10

    @api.constrains('document_type', 'cedula')
    def _check_document_validation(self):
        for rec in self:
            if rec.document_type == 'cedula':
                if not self.is_valid_ecuadorian_id(rec.cedula):
                    raise ValidationError("La cédula ecuatoriana no es válida.")
            elif rec.document_type == 'id_extrj':
                if not self.is_valid_foreign_id(rec.cedula):
                    raise ValidationError("La cédula extranjera debe tener 10 dígitos numéricos.")
            elif rec.document_type == 'pasaporte':
                # No se valida nada, se permite cualquier valor
                pass


class HrCandidate(models.Model):
    _inherit = 'hr.candidate'

    firstname = fields.Char(string="Nombres")
    lastname_paterno = fields.Char(string="Apellido Paterno")
    lastname_materno = fields.Char(string="Apellido Materno")

    name = fields.Char(string="Nombre completo", compute="_compute_name", store=True)

    @api.depends('firstname', 'lastname_paterno', 'lastname_materno')
    def _compute_name(self):
        for record in self:
            record.name = " ".join(filter(None, [
                record.lastname_paterno,
                record.lastname_materno,
                record.firstname
            ]))


class ApplicantDocument(models.Model):
    _name = 'applicant.document'
    _description = 'Documentos del postulante'

    applicant_id = fields.Many2one('hr.applicant', string="Postulante", ondelete="cascade")
    file = fields.Binary("Archivo")
    filename = fields.Char("Nombre del archivo")

class HrApplicant(models.Model):
    _inherit = 'hr.applicant'

    is_readonly_group = fields.Boolean(
        compute='_compute_is_readonly_group'
    )

    @api.depends_context('uid')
    def _compute_is_readonly_group(self):
        for rec in self:
            rec.is_readonly_group = self.env.user.has_group(
                'custom_web_hr_datos_candidatos.group_applicant_readonly'
            )